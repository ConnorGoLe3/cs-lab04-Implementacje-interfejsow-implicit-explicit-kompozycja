﻿using System;
using System.CodeDom;

namespace ver2
{
    public interface IDevice
    {
        enum State { on, off };

        void PowerOn(); // uruchamia urządzenie, zmienia stan na `on`
        void PowerOff(); // wyłącza urządzenie, zmienia stan na `off
        State GetState(); // zwraca aktualny stan urządzenia

        int Counter { get; }  // zwraca liczbę charakteryzującą eksploatację urządzenia,
        // np. liczbę uruchomień, liczbę wydrukow, liczbę skanów, ...
    }

    public abstract class BaseDevice : IDevice
    {
        protected IDevice.State state = IDevice.State.off;
        public IDevice.State GetState() => state;

        public void PowerOff()
        {
            state = IDevice.State.off;
            Console.WriteLine("... Device is off !");
        }

        public void PowerOn()
        {
            state = IDevice.State.on;
            Console.WriteLine("Device is on ...");
        }

        public int Counter { get; private set; } = 0;
    }

    public interface IPrinter : IDevice
    {
        /// <summary>
        /// Dokument jest drukowany, jeśli urządzenie włączone. W przeciwnym przypadku nic się nie wykonuje
        /// </summary>
        /// <param name="document">obiekt typu IDocument, różny od `null`</param>
        void Print(in IDocument document);
    }

    public interface IScanner : IDevice
    {
        // dokument jest skanowany, jeśli urządzenie włączone
        // w przeciwnym przypadku nic się dzieje
        void Scan(out IDocument document, IDocument.FormatType formatType);
    }

    public interface IFax : IDevice
    {
        void Send(in IDocument document);
    }

    public class Fax : BaseDevice, IFax
    {
        public new int Counter { get; private set; } = 0;
        public int SendCounter { get; private set; } = 0;

        public new void PowerOff()
        {
            state = IDevice.State.off;
        }

        public new void PowerOn()
        {
            if (GetState() == IDevice.State.off) ++Counter;
            state = IDevice.State.on;
        }

        public void Send(in IDocument document)
        {
            if (GetState() == IDevice.State.off) return;

            ++SendCounter;
            Console.WriteLine("Send");
        }
    }

    public class Printer : BaseDevice, IPrinter
    {
        public new int Counter { get; private set; } = 0;
        public int PrintCounter { get; private set; } = 0;

        public new void PowerOff()
        {
            state = IDevice.State.off;
        }

        public new void PowerOn()
        {
            if (GetState() == IDevice.State.off) ++Counter;
            state = IDevice.State.on;
        }

        public void Print(in IDocument document)
        {
            if (GetState() == IDevice.State.off) return;

            ++PrintCounter;
            Console.WriteLine($"{DateTime.Now} Print {document.GetFileName()}");
        }
    }
    public class Scanner : BaseDevice, IScanner
    {
        public new int Counter { get; private set; } = 0;
        public int ScanCounter { get; private set; } = 0;

        public new void PowerOff()
        {
            state = IDevice.State.off;
        }

        public new void PowerOn()
        {
            if (GetState() == IDevice.State.off) ++Counter;
            state = IDevice.State.on;
        }

        public void Scan(out IDocument document, IDocument.FormatType formatType = IDocument.FormatType.PDF)
        {
            document = null;
            if (GetState() == IDevice.State.off) return;

            ++ScanCounter;
            switch (formatType)
            {
                case IDocument.FormatType.PDF:
                    document = new PDFDocument($"PDFScan{ScanCounter}.pdf");
                    Console.WriteLine($"{DateTime.Now} Scan: {document.GetFileName()}");
                    break;

                case IDocument.FormatType.JPG:
                    document = new ImageDocument($"ImageScan{ScanCounter}.jpg");
                    Console.WriteLine($"{DateTime.Now} Scan: {document.GetFileName()}");
                    break;

                case IDocument.FormatType.TXT:
                    document = new TextDocument($"TextScan{ScanCounter}.txt");
                    Console.WriteLine($"{DateTime.Now} Scan: {document.GetFileName()}");
                    break;
            }
        }
    }

    public class Copier : BaseDevice
    {
        public Printer printer = new();
        public Scanner scanner = new();

        public new int Counter { get; private set; } = 0;
        public int PrintCounter => printer.PrintCounter;
        public int ScanCounter => scanner.ScanCounter;

        public new void PowerOff()
        {
            state = IDevice.State.off;
        }

        public new void PowerOn()
        {
            if (GetState() == IDevice.State.off) ++Counter;
            state = IDevice.State.on;
        }

        public void Print(in IDocument document)
        {
            if (GetState() == IDevice.State.off) return;

            printer.PowerOn();
            printer.Print(document);
            printer.PowerOff();
        }

        public void Scan(out IDocument document, IDocument.FormatType formatType = IDocument.FormatType.PDF)
        {
            document = null;
            if (GetState() == IDevice.State.off) return;
            scanner.PowerOn();
            scanner.Scan(out document, formatType);
            scanner.PowerOff();
        }

        public void ScanAndPrint()
        {
            if (GetState() == IDevice.State.off) return;

            IDocument document;

            scanner.PowerOn();
            printer.PowerOn();

            scanner.Scan(out document, IDocument.FormatType.JPG);
            printer.Print(document);

            printer.PowerOff();
            scanner.PowerOff();
        }
    }

    public class MultidimensionalDevice : BaseDevice
    {
        public Copier copier = new ();
        public Fax fax = new ();

        public new int Counter { get; private set; } = 0;
        public int PrintCounter => copier.printer.PrintCounter;
        public int ScanCounter => copier.scanner.ScanCounter;
        public int SendCounter => fax.SendCounter;

        public new void PowerOff()
        {
            state = IDevice.State.off;
        }

        public new void PowerOn()
        {
            if (GetState() == IDevice.State.off) ++Counter;
            state = IDevice.State.on;
        }

        public void Print(in IDocument document)
        {
            if (GetState() == IDevice.State.off) return;
            copier.PowerOn();
            copier.Print(in document);
            copier.PowerOff();
        }

        public void Scan(out IDocument document, IDocument.FormatType formatType = IDocument.FormatType.PDF)
        {
            document = null;
            if (GetState() == IDevice.State.off) return;
            copier.PowerOn();
            copier.Scan(out document, formatType);
            copier.PowerOff();
        }

        public void Send(in IDocument document)
        {
            if (GetState() == IDevice.State.off) return;
            fax.PowerOn();
            fax.Send(document);
            fax.PowerOff();
        }
    }
}